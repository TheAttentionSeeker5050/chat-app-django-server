# these 2 lines of code are for mysql to work on django settings
import pymysql
pymysql.install_as_MySQLdb()